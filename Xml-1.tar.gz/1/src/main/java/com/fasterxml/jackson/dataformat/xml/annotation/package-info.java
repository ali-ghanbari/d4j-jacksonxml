/**
 * Package that contains additional annotations that can be
 * used to configure XML-specific aspects of serialization
 * and deserialization
 */
package com.fasterxml.jackson.dataformat.xml.annotation;
